from django.conf import settings
from django.db import models
from mapbox_location_field.models import LocationField
from model_utils.models import TimeStampedModel


class Customer(TimeStampedModel):

    name = models.CharField(max_length=200)
    shop_name = models.CharField(
        max_length=200,
        null=True,
        blank=True,
        help_text='Optional'
        )
    vat_no = models.IntegerField(
        'VAT No.',
        null=True,
        blank=True,
        help_text='Optional'
        )
    location = LocationField(map_attrs=settings.MAP_ATTRS)

    def __str__(self):
        return self.name
