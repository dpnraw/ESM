from django.conf import settings
from django.contrib import admin
from django.db.models import Sum
from mapbox_location_field.admin import MapAdmin

from sales.models import Sale

from .models import Customer


@admin.register(Customer)
class CustomerAdmin(MapAdmin, admin.ModelAdmin):
    '''Admin View for Customer'''

    list_display = (
        'name',
        'shop_name',
        'vat_no',
        '_location',
        'transaction',
        'total_paid',
        'cash_paid',
        'cheque_paid',
        'due_balance',
        )

    def _location(self, obj):
        """ Returns location of customer.
        """

        latitude = obj.location[1]
        longitude = obj.location[0]
        use_reverse_geocoding = settings.USE_REVERSE_GEOCODING
        if use_reverse_geocoding:
            import reverse_geocoder as rg
            result = rg.search((latitude, longitude))
            return f'{result[0]["name"]}, { result[0]["admin2"]}, {result[0]["admin1"]}, {result[0]["cc"]}'
        else:
            return f'{round(latitude,2)}, {round(longitude,2)}'
    _location.short_description = 'Location'

    def transaction(self, obj):
        """ Returns total transaction done by customer.
        """

        if Sale.objects.filter(customer=obj).exists():
            customer_sales = Sale.objects.filter(customer=obj)
            total_transaction = 0

            for customer_sale in customer_sales:
                transaction = customer_sale.total_price
                total_transaction += transaction
            return total_transaction
        else:
            return 0.0

    def total_paid(self, obj):
        """ Returns total paid amount by customer.
        """

        if Sale.objects.filter(customer=obj).exists():
            customer_sales = Sale.objects.filter(customer=obj)
            total_paid = 0

            for customer_sale in customer_sales:
                amount_paid = customer_sale.payments.all().exclude(
                    type='CR'
                ).aggregate(
                    sum=Sum('amount')
                ).get('sum') or 0.0
                total_paid += amount_paid
            return total_paid
        else:
            return 0.0

    def cash_paid(self, obj):
        """ Returns total cash paid amount by customer.
        """

        if Sale.objects.filter(customer=obj).exists():
            customer_sales = Sale.objects.filter(customer=obj)
            total_cash_paid = 0

            for customer_sale in customer_sales:
                cash_paid = customer_sale.amount_received
                total_cash_paid += cash_paid
            return total_cash_paid
        else:
            return 0.0

    def cheque_paid(self, obj):
        """ Returns total cheque paid amount by customer.
        """

        if Sale.objects.filter(customer=obj).exists():
            customer_sales = Sale.objects.filter(customer=obj)
            total_cheque_paid = 0

            for customer_sale in customer_sales:
                cheque_paid = customer_sale.cheque_balance
                total_cheque_paid += cheque_paid
            return total_cheque_paid
        else:
            return 0.0

    def due_balance(self, obj):
        """ Returns total due balance to be paid by customer.
        """

        if Sale.objects.filter(customer=obj).exists():
            customer_sales = Sale.objects.filter(customer=obj)
            total_due_balance = 0

            for customer_sale in customer_sales:
                due_balance = customer_sale.due_balance
                total_due_balance += due_balance
            return total_due_balance
        else:
            return 0.0
