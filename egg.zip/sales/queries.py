QUERY_WHITELIST = [
    'date_range_gte',
    'date_range_lte',
    'date__gte',
    'date__gte',
    'date__gte',
    'date__lt',
    'customer__id__exact',
]
